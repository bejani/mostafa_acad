<?php

namespace App\Core;

class Router
{
    private array $routes = [
        'GET' => [],
        'POST' => [],
    ];

    public function get(string $path, $handler)
    {
        $this->routes['GET'][$path] = $handler;
    }

    public function post(string $path, $handler)
    {
        $this->routes['POST'][$path] = $handler;
    }

    public function dispatch()
    {
        // مسیر کامل از URL
        $uri = $_SERVER['REQUEST_URI'];

        // فقط بخش PATH را می‌گیریم
        $uri = parse_url($uri, PHP_URL_PATH);

        // حذف مسیر ثابت هاست
        // /tvto_portal/public  ← پوشه اصلی پروژه روی هاست
        $base = '/tvto_portal/public';

        if (strpos($uri, $base) === 0) {
            $uri = substr($uri, strlen($base));
        }

        // حذف /index.php
        if ($uri === '/index.php') {
            $uri = '/';
        }

        // مسیر خالی → /
        if ($uri === '' || $uri === false) {
            $uri = '/';
        }

        $method = $_SERVER['REQUEST_METHOD'];

        if (!isset($this->routes[$method][$uri])) {
            http_response_code(404);
            echo "404: route not found → $uri";
            return;
        }

        echo $this->routes[$method][$uri]();
    }
}