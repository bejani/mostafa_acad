<?php

namespace App\Core;

class View
{
    /**
     * رندر صفحه با لی‌اوت
     */
    public static function render(string $template, array $data = [], ?string $layout = 'admin')
    {
        $templateFile = __DIR__ . '/../Template/' . $template;

        if (!file_exists($templateFile)) {
            throw new \Exception("View file not found: $templateFile");
        }

        extract($data);

        ob_start();
        require $templateFile;
        $content = ob_get_clean();

        if ($layout === null) {
            return $content;
        }

        $layoutFile = __DIR__ . '/../Template/layouts/' . $layout . '.php';

        if (!file_exists($layoutFile)) {
            throw new \Exception("Layout not found: $layoutFile");
        }

        ob_start();
        require $layoutFile;
        return ob_get_clean();
    }

    /**
     * Base URL — همیشه ثابت و بدون وابستگی به Session
     */
    public static function baseUrl(string $path = '')
    {
        // آدرس اصلی پروژه روی هاست
        $base = '/tvto_portal/public';

        // خروجی نهایی
        return rtrim($base, '/') . '/' . ltrim($path, '/');
    }

    /**
     * Redirect
     */
    public static function redirect(string $path)
    {
        $url = self::baseUrl($path);
        header("Location: $url");
        exit;
    }
}