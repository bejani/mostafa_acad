<?php

return [
    'db' => [
        'host' => 'localhost',
        'name' => 'tvto',
        'user' => 'root',
        'pass' => '4562',
        'charset' => 'utf8mb4'
    ],
    // 'db' => [
    //     'host' => 'sql113.infinityfree.com',
    //     'dbname' => 'if0_40388701_drtvto',
    //     'user' => 'if0_40388701',
    //     'pass' => 'qbXxne38Tl',
    //     'charset' => 'utf8mb4'
    // ],
    'base_url' => 'http://localhost/tvto_portal/public'
];