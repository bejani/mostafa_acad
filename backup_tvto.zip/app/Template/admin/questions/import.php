<h3 class="mb-4">ایمپورت سؤالات از Word</h3>

<form method="post" action="/tvto_portal/public/admin/questions/import" enctype="multipart/form-data">

    <input type="hidden" name="quiz_id" value="<?= $quiz_id ?>">

    <div class="mb-3">
        <label class="form-label">فایل Word (docx)</label>
        <input type="file" name="docx" class="form-control" required>
    </div>

    <button class="btn btn-primary">ایمپورت</button>

    <a href="/tvto_portal/public/admin/questions?quiz_id=<?= $quiz_id ?>" class="btn btn-secondary">
        بازگشت
    </a>
</form>