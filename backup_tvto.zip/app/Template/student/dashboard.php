<style>
.dashboard-card {
    padding: 25px;
    border-radius: 15px;
    color: #fff;
    text-align: center;
    transition: .3s ease;
    cursor: pointer;
}

.dashboard-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, .2);
}

.icon {
    font-size: 50px;
    margin-bottom: 15px;
    transition: .3s;
}

.dashboard-card:hover .icon {
    transform: scale(1.15) rotate(3deg);
}

.card-1 {
    background: linear-gradient(45deg, #0d6efd, #3c8dfd);
}

.card-2 {
    background: linear-gradient(45deg, #6610f2, #8a3ef2);
}

.card-3 {
    background: linear-gradient(45deg, #198754, #23a06d);
}

.card-4 {
    background: linear-gradient(45deg, #dc3545, #f55767);
}

.counter {
    font-size: 2.3rem;
    font-weight: bold;
}
</style>

<div class="row g-4">

    <div class="col-md-3 col-6">
        <a href="/tvto_portal/public/student/contents" class="text-decoration-none">
            <div class="dashboard-card card-1">
                <div class="icon">📘</div>
                <h5>محتواهای آموزشی</h5>
                <div class="counter"><?= $contentCount ?></div>
            </div>
        </a>
    </div>

    <div class="col-md-3 col-6">
        <a href="/tvto_portal/public/student/quizzes" class="text-decoration-none">
            <div class="dashboard-card card-2">
                <div class="icon">📝</div>
                <h5>آزمون‌ها</h5>
                <div class="counter"><?= $quizCount ?></div>
            </div>
        </a>
    </div>

    <div class="col-md-3 col-6">
        <a href="/tvto_portal/public/student/results" class="text-decoration-none">
            <div class="dashboard-card card-3">
                <div class="icon">📊</div>
                <h5>نتایج آزمون‌ها</h5>
                <div class="counter"><?= $resultCount ?></div>
            </div>
        </a>
    </div>

    <div class="col-md-3 col-6">
        <a href="/tvto_portal/public/student/change-password" class="text-decoration-none">
            <div class="dashboard-card card-4">
                <div class="icon">🔑</div>
                <h5>تغییر رمز</h5>
            </div>
        </a>
    </div>

</div>