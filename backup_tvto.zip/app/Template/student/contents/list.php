<div class="container">

    <h3 class="mb-4">محتواهای آموزشی</h3>

    <?php if (empty($contents)): ?>
    <div class="alert alert-info">هیچ محتوایی برای نمایش وجود ندارد.</div>
    <?php else: ?>

    <div class="row g-4">

        <?php foreach ($contents as $c): ?>

        <div class="col-md-6 col-lg-4">
            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <h5 class="card-title"><?= htmlspecialchars($c['title']) ?></h5>
                    <p class="text-muted">دسته: <?= htmlspecialchars($c['category']) ?></p>

                    <?php
                            $type = strtolower($c['type']);
                            $path = trim($c['path']);
                            $link = trim($c['link_url']);
                            $isAparat = str_contains($path, 'aparat.com') || str_contains($link, 'aparat.com');
                            ?>

                    <?php if ($type === 'video' || $isAparat): ?>

                    <!-- دکمه مشاهده (برای ویدئوها) -->
                    <button class="btn btn-primary w-100 mt-3 view-btn" data-bs-toggle="modal"
                        data-bs-target="#contentModal" data-title="<?= htmlspecialchars($c['title']) ?>"
                        data-type="<?= htmlspecialchars($type) ?>" data-path="<?= htmlspecialchars($path) ?>"
                        data-link="<?= htmlspecialchars($link) ?>">
                        مشاهده
                    </button>

                    <?php else: ?>
                    <!-- دکمه دانلود برای فایل‌ها -->
                    <?php
                                $fileUrl = $path ?: $link;

                                // اگر لینک خارجی نبود، baseUrl اضافه کن
                                if (!str_starts_with($fileUrl, 'http')) {
                                    $fileUrl = \App\Core\View::baseUrl($fileUrl);
                                }
                                ?>
                    <a href="<?= $fileUrl ?>" class="btn btn-success w-100 mt-3" target="_blank">
                        دانلود
                    </a>
                    <?php endif; ?>

                </div>

            </div>
        </div>

        <?php endforeach; ?>

    </div>

    <?php endif; ?>
</div>


<!-- ======================= -->
<!--        MODAL            -->
<!-- ======================= -->
<div class="modal fade" id="contentModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">نمایش محتوا</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body" id="modalBody" style="min-height: 480px;">
                در حال بارگذاری...
            </div>

        </div>
    </div>
</div>


<script>
document.addEventListener("DOMContentLoaded", () => {
    const modalBody = document.getElementById("modalBody");
    const modalTitle = document.getElementById("modalTitle");

    document.querySelectorAll(".view-btn").forEach(btn => {
        btn.addEventListener("click", () => {

            let title = btn.dataset.title;
            let type = btn.dataset.type;
            let path = btn.dataset.path;
            let link = btn.dataset.link;

            modalTitle.textContent = title;
            modalBody.innerHTML = "در حال بارگذاری...";

            let isAparat = (path.includes("aparat.com") || link.includes("aparat.com"));

            if (isAparat) {
                modalBody.innerHTML = `
                    <div class="ratio ratio-16x9">
                        <iframe src="${path || link}" allowfullscreen></iframe>
                    </div>
                `;
            } else if (type === "video") {
                modalBody.innerHTML = `
                    <video controls class="w-100">
                        <source src="${path}" type="video/mp4">
                    </video>
                `;
            } else {
                modalBody.innerHTML = `
                    <p class="text-danger">این محتوا قابل نمایش در مودال نیست.</p>
                `;
            }
        });
    });
});
</script>