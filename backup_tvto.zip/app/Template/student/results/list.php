<h3 class="mb-4">نتایج آزمون‌های شما</h3>

<table class="table table-bordered table-striped text-center">
    <thead class="table-dark">
        <tr>
            <th>آزمون</th>
            <th>نمره</th>
            <th>مدت (ثانیه)</th>
            <th>تاریخ</th>
        </tr>
    </thead>

    <tbody>
        <?php foreach ($attempts as $a): ?>
        <tr>
            <td><?= $a['quiz_title'] ?></td>
            <td><?= $a['score'] ?>%</td>
            <td><?= $a['duration_seconds'] ?></td>
            <td><?= $a['finished_at'] ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>