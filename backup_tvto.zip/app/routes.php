<?php

use App\Core\Router;
use App\Action\Auth\LoginAction;
use App\Action\Auth\DoLoginAction;
use App\Action\Auth\LogoutAction;

use App\Action\Admin\AdminDashboardAction;
use App\Action\Student\StudentPanelAction;
use App\Action\Student\ChangePasswordFormAction;
use App\Action\Student\ChangePasswordAction;

// $router = new Router();

// login
$router->get('/', new LoginAction());
$router->get('/login', new LoginAction());
$router->post('/login', new DoLoginAction());

// logout
$router->get('/logout', new LogoutAction());

// admin dashboard
$router->get('/admin/dashboard', new AdminDashboardAction());

// student panel
$router->get('/student/panel', new StudentPanelAction());
// Content Management (Admin)
$router->get('/admin/contents', new \App\Action\Admin\Content\ContentListAction());
$router->get('/admin/contents/create', new \App\Action\Admin\Content\ContentCreateFormAction());
$router->post('/admin/contents/create', new \App\Action\Admin\Content\ContentCreateAction());
$router->get('/admin/contents/edit', new \App\Action\Admin\Content\ContentEditFormAction());
$router->post('/admin/contents/edit', new \App\Action\Admin\Content\ContentEditAction());
$router->get('/admin/contents/delete', new \App\Action\Admin\Content\ContentDeleteAction());
// مدیریت کاربران
$router->get('/admin/users', new \App\Action\Admin\User\UserListAction());
$router->get('/admin/users/create', new \App\Action\Admin\User\UserCreateFormAction());
$router->post('/admin/users/create', new \App\Action\Admin\User\UserCreateAction());
$router->get('/admin/users/edit', new \App\Action\Admin\User\UserEditFormAction());
$router->post('/admin/users/edit', new \App\Action\Admin\User\UserEditAction());
$router->get('/admin/users/delete', new \App\Action\Admin\User\UserDeleteAction());
$router->get('/admin/users/toggle', new \App\Action\Admin\User\UserToggleAction());
// ----------------------
// مدیریت آزمون‌ها (ادمین)
// ----------------------
$router->get('/admin/quizzes',        new \App\Action\Admin\Quiz\QuizListAction());
$router->get('/admin/quizzes/create', new \App\Action\Admin\Quiz\QuizCreateFormAction());
$router->post('/admin/quizzes/create', new \App\Action\Admin\Quiz\QuizCreateAction());
$router->get('/admin/quizzes/edit',   new \App\Action\Admin\Quiz\QuizEditFormAction());
$router->post('/admin/quizzes/edit',  new \App\Action\Admin\Quiz\QuizEditAction());
$router->get('/admin/quizzes/delete', new \App\Action\Admin\Quiz\QuizDeleteAction());
// مدیریت سوالات
$router->get('/admin/questions',        new \App\Action\Admin\Question\QuestionListAction());
$router->get('/admin/questions/create', new \App\Action\Admin\Question\QuestionCreateFormAction());
$router->post('/admin/questions/create', new \App\Action\Admin\Question\QuestionCreateAction());
$router->get('/admin/questions/edit',   new \App\Action\Admin\Question\QuestionEditFormAction());
$router->post('/admin/questions/edit',  new \App\Action\Admin\Question\QuestionEditAction());
$router->get('/admin/questions/delete', new \App\Action\Admin\Question\QuestionDeleteAction());

// ایمپورت ورد
$router->get('/admin/questions/import', new \App\Action\Admin\Question\QuestionImportFormAction());
$router->post('/admin/questions/import', new \App\Action\Admin\Question\QuestionImportDocxAction());
// Student quiz
$router->get('/student/panel', new \App\Action\Student\DashboardAction());
$router->get('/student/contents',  new \App\Action\Student\ContentListAction());
$router->get('/student/quizzes',   new \App\Action\Student\QuizListAction());
$router->get('/student/take',      new \App\Action\Student\QuizTakeAction());
$router->post('/student/submit',   new \App\Action\Student\QuizSubmitAction());
$router->get('/student/results',   new \App\Action\Student\ResultListAction());

// تغییر رمز
$router->get('/student/change-password', new ChangePasswordFormAction());
$router->post('/student/change-password', new ChangePasswordAction());

return $router;