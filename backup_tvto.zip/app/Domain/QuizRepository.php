<?php

namespace App\Domain;

use App\Core\Database;
use PDO;

class QuizRepository
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function all(): array
    {
        $stmt = $this->db->query("SELECT * FROM quizzes ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public function allPublished(): array
    {
        $stmt = $this->db->query("SELECT * FROM quizzes WHERE is_published = 1 ORDER BY id DESC");
        return $stmt->fetchAll();
    }
    public function countPublished()
    {
        $db = Database::getConnection();
        return $db->query("SELECT COUNT(*) AS c FROM quizzes WHERE is_published = 1")
            ->fetch()['c'];
    }


    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM quizzes WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int
    {
        $stmt = $this->db->prepare(
            "INSERT INTO quizzes (title, module, time_limit_seconds, question_count, is_published, created_by)
             VALUES (?, ?, ?, ?, ?, ?)"
        );

        $stmt->execute([
            $data['title'],
            $data['module'],
            $data['time_limit_seconds'] ?? 0,
            $data['question_count'] ?? 0,
            $data['is_published'] ?? 0,
            $data['created_by'] ?? null,
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE quizzes
             SET title=?, module=?, time_limit_seconds=?, question_count=?, is_published=?
             WHERE id=?"
        );

        return $stmt->execute([
            $data['title'],
            $data['module'],
            $data['time_limit_seconds'] ?? 0,
            $data['question_count'] ?? 0,
            $data['is_published'] ?? 0,
            $id,
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM quizzes WHERE id=?");
        return $stmt->execute([$id]);
    }
}