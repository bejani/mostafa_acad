<?php

namespace App\Domain;

use App\Core\Database;
use PDO;

class AttemptRepository
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    /**
     * ایجاد تلاش جدید (Attempt)
     */
    public function create(array $data)
    {
        $stmt = $this->db->prepare("
            INSERT INTO attempts (quiz_id, user_id, started_at, score, duration_seconds)
            VALUES (?, ?, NOW(), ?, ?)
        ");

        $stmt->execute([
            $data['quiz_id'],
            $data['user_id'],
            $data['score'] ?? 0,
            $data['duration_seconds'] ?? 0
        ]);

        return $this->db->lastInsertId();
    }


    /**
     * یافتن تلاش (Attempt)
     */
    public function find($attemptId)
    {
        $stmt = $this->db->prepare("SELECT * FROM attempts WHERE id=?");
        $stmt->execute([$attemptId]);
        return $stmt->fetch();
    }

    public function countByUser($userId)
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("SELECT COUNT(*) AS c FROM attempts WHERE user_id = ?");
        $stmt->execute([$userId]);
        return $stmt->fetch()['c'];
    }

    /**
     * ذخیره یک پاسخ در attempt_answers
     */
    public function saveAnswer($attemptId, $questionId, $optionId)
    {
        $stmt = $this->db->prepare("
            INSERT INTO attempt_answers (attempt_id, question_id, selected_option_ids)
            VALUES (?, ?, ?)
        ");
        return $stmt->execute([
            $attemptId,
            $questionId,
            json_encode([$optionId])
        ]);
    }


    /**
     * پایان دادن به آزمون — ثبت score و مدت زمان
     */
    public function finish($attemptId, $score, $duration)
    {
        $stmt = $this->db->prepare("
            UPDATE attempts
            SET score=?, finished_at=NOW(), duration_seconds=?
            WHERE id=?
        ");

        return $stmt->execute([$score, $duration, $attemptId]);
    }


    /**
     * تمام تلاش‌های یک دانش‌آموز
     */
    public function getUserAttempts($userId)
    {
        $stmt = $this->db->prepare("
            SELECT a.*, q.title AS quiz_title
            FROM attempts a
            JOIN quizzes q ON q.id = a.quiz_id
            WHERE a.user_id=?
            ORDER BY a.id DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }
}