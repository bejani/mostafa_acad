<?php

namespace App\Action\Admin\Content;

use App\Core\View;
use App\Core\Auth;
use App\Domain\ContentRepository;

class ContentCreateAction
{
    public function __invoke()
    {
        if (!Auth::isAdmin()) {
            View::redirect("/tvto_portal/public/login");
        }

        $title       = $_POST['title'];
        $type        = $_POST['type'];
        $category    = $_POST['category'];
        $description = $_POST['description'] ?? '';
        $link_url    = $_POST['link_url'] ?? null;

        $path = null;

        // مسیر آپلود فایل
        $uploadDir = __DIR__ . "/../../../../public/uploads";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // 1) آپلود فایل‌های غیر ویدئویی (PDF, Word, Excel, PowerPoint)
        if (!empty($_FILES['file_doc']['name'])) {

            $filename = time() . "_" . basename($_FILES['file_doc']['name']);
            $target   = $uploadDir . "/" . $filename;

            if (move_uploaded_file($_FILES['file_doc']['tmp_name'], $target)) {
                $path = "/uploads/" . $filename;
            }
        }

        // 2) آپلود فایل ویدئو
        if (!empty($_FILES['file_video']['name'])) {

            $filename = time() . "_" . basename($_FILES['file_video']['name']);
            $target   = $uploadDir . "/" . $filename;

            if (move_uploaded_file($_FILES['file_video']['tmp_name'], $target)) {
                $path = "/uploads/" . $filename;
            }
        }

        // 3) اگر نوع ویدئو باشد اما فایل ویدئو آپلود نشده باشد → لینک آپارات را embed کن
        if ($type === "video" && empty($path) && !empty($link_url)) {

            $hash = null;

            // استخراج کد آپارات
            if (preg_match('~/v/([^/]+)~', $link_url, $m)) {
                $hash = $m[1];
            }

            if ($hash) {
                $path = "https://www.aparat.com/video/video/embed/videohash/$hash/vt/frame";
            }
        }

        // 4) ذخیره در دیتابیس
        $repo = new ContentRepository();
        $repo->create([
            "title"       => $title,
            "type"        => $type,
            "category"    => $category,
            "path"        => $path,
            "link_url"    => $link_url,
            "description" => $description,
            "created_by"  => Auth::user()['id']
        ]);

        View::redirect("/tvto_portal/public/admin/contents");
    }
}