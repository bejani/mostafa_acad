<?php

namespace App\Action\Admin\Content;

use App\Core\View;
use App\Core\Auth;
use App\Domain\ContentRepository;

class ContentEditAction
{
    public function __invoke()
    {
        if (!Auth::isAdmin()) {
            View::redirect("/tvto_portal/public/login");
        }

        $id          = $_POST['id'];
        $title       = $_POST['title'];
        $type        = $_POST['type'];
        $description = $_POST['description'];
        $link_url    = $_POST['link_url'] ?? null;
        $category = $_POST['category'];


        $repo = new ContentRepository();
        $content = $repo->find($id);

        if (!$content) {
            View::redirect("/tvto_portal/public/admin/contents");
        }

        $path = $content['path']; // مقدار قبلی

        $uploadDir = __DIR__ . "/../../../../public/uploads";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // 1) آپلود فایل غیر ویدئو
        if (!empty($_FILES['file_doc']['name'])) {
            $filename = time() . "_" . basename($_FILES['file_doc']['name']);
            $target   = $uploadDir . "/" . $filename;

            if (move_uploaded_file($_FILES['file_doc']['tmp_name'], $target)) {
                $path = "/uploads/" . $filename;
            }
        }

        // 2) آپلود فایل ویدئو
        if (!empty($_FILES['file_video']['name'])) {
            $filename = time() . "_" . basename($_FILES['file_video']['name']);
            $target   = $uploadDir . "/" . $filename;

            if (move_uploaded_file($_FILES['file_video']['tmp_name'], $target)) {
                $path = "/uploads/" . $filename;
            }
        }

        // 3) ساخت embed برای لینک آپارات در صورت نیاز
        if ($type === "video" && empty($_FILES['file_video']['name']) && !empty($link_url)) {

            $hash = null;
            if (preg_match('~/v/([^/]+)~', $link_url, $m)) {
                $hash = $m[1];
            }

            if ($hash) {
                $path = "https://www.aparat.com/video/video/embed/videohash/$hash/vt/frame";
            }
        }

        // 4) بروزرسانی دیتابیس

        $repo->update($id, [
            "title"       => $title,
            "type"        => $type,
            "category"    => $category,
            "description" => $description,
            "link_url"    => $link_url,
            "path"        => $path
        ]);


        View::redirect("/tvto_portal/public/admin/contents");
    }
}