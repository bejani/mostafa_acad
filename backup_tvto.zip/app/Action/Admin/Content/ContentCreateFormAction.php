<?php

namespace App\Action\Admin\Content;

use App\Core\View;
use App\Core\Auth;

class ContentCreateFormAction
{
    public function __invoke()
    {
        if (!Auth::isAdmin()) View::redirect("/tvto_portal/public/login");

        return View::render("admin/content/create.php", []);
    }
}