<?php

namespace App\Action\Admin\Content;

use App\Core\View;
use App\Core\Auth;
use App\Domain\ContentRepository;

class ContentDeleteAction
{
    public function __invoke()
    {
        if (!Auth::isAdmin()) View::redirect("/tvto_portal/public/login");

        $id = $_GET['id'];
        $repo = new ContentRepository();
        $repo->delete($id);

        View::redirect("/tvto_portal/public/admin/contents");
    }
}