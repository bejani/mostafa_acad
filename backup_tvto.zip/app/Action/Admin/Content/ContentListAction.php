<?php

namespace App\Action\Admin\Content;

use App\Core\View;
use App\Core\Auth;
use App\Domain\ContentRepository;

class ContentListAction
{
    public function __invoke()
    {
        if (!Auth::isAdmin()) View::redirect("/tvto_portal/public/login");

        $repo = new ContentRepository();
        $contents = $repo->all();

        return View::render("admin/content/list.php", [
            "contents" => $contents
        ]);
    }
}