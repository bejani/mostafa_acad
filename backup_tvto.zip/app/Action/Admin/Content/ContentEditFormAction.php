<?php

namespace App\Action\Admin\Content;

use App\Core\View;
use App\Core\Auth;
use App\Domain\ContentRepository;

class ContentEditFormAction
{
    public function __invoke()
    {
        if (!Auth::isAdmin()) {
            View::redirect("/tvto_portal/public/login");
        }

        $id = $_GET['id'] ?? null;
        if (!$id) {
            View::redirect("/tvto_portal/public/admin/contents");
        }

        $repo = new ContentRepository();
        $content = $repo->find($id);

        if (!$content) {
            View::redirect("/tvto_portal/public/admin/contents");
        }

        return View::render("admin/content/edit.php", [
            'content' => $content
        ]);
    }
}