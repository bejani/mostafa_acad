<?php

namespace App\Action\Admin\Question;

use App\Core\Auth;
use App\Core\View;
use App\Domain\QuestionRepository;

class QuestionEditAction
{
    public function __invoke()
    {
        // فقط ادمین دسترسی دارد
        if (!Auth::isAdmin()) {
            return View::redirect(View::baseUrl('/login'));
        }

        // دریافت و اعتبارسنجی ورودی‌ها
        $id     = (int)($_POST['id'] ?? 0);
        $quizId = (int)($_POST['quiz_id'] ?? 0);

        if ($id <= 0 || $quizId <= 0) {
            return View::redirect(View::baseUrl('/admin/quizzes'));
        }

        $body        = trim($_POST['body'] ?? '');
        $type        = $_POST['type'] ?? 'mcq_single';
        $explain     = trim($_POST['explanation'] ?? '');
        $difficulty  = 2;

        $repo = new QuestionRepository();

        // ---- 1) آپدیت خود سؤال ----
        $repo->updateQuestion($id, [
            'body'        => $body,
            'type'        => $type,
            'explanation' => $explain,
            'difficulty'  => $difficulty,
        ]);

        // ---- 2) حذف گزینه‌های قبلی ----
        $repo->deleteOptions($id);

        // ---- 3) ثبت گزینه‌های جدید ----
        $options = $_POST['options'] ?? [];
        $correct = $_POST['correct'] ?? [];  // indexهای گزینه‌های صحیح

        foreach ($options as $i => $optText) {
            $optText = trim($optText);
            if ($optText === '') continue;

            // آیا این index صحیح است؟
            $isCorrect = in_array((string)$i, $correct, true) ? 1 : 0;

            $repo->addOption($id, $optText, $isCorrect);
        }

        // بازگشت به لیست سوالات
        return View::redirect(
            View::baseUrl('/admin/questions?quiz_id=' . $quizId)
        );
    }
}