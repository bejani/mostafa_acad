<?php

namespace App\Action\Admin\Question;

use App\Core\Auth;
use App\Core\View;
use App\Domain\QuestionRepository;

class QuestionEditFormAction
{
    public function __invoke()
    {
        // جلوگیری از دسترسی غیر ادمین
        if (!Auth::isAdmin()) {
            return View::redirect(View::baseUrl('/login'));
        }

        // دریافت id سوال
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            return View::redirect(View::baseUrl('/admin/quizzes'));
        }

        $repo = new QuestionRepository();

        // دریافت سؤال
        $question = $repo->findQuestion($id);   // ← متد صحیح

        if (!$question) {
            return View::redirect(View::baseUrl('/admin/quizzes'));
        }

        // دریافت گزینه‌های سؤال
        $options = $repo->getOptions($id);      // ← متد صحیح

        // ارسال به ویو
        return View::render('admin/questions/edit.php', [
            'question' => $question,
            'options'  => $options
        ]);
    }
}