<?php

namespace App\Action\Admin\Question;

use App\Core\Auth;
use App\Core\View;
use App\Domain\QuestionRepository;

use PhpOffice\PhpWord\IOFactory;

class QuestionImportDocxAction
{
    public function __invoke()
    {
        if (!Auth::isAdmin()) {
            View::redirect("/tvto_portal/public/login");
        }

        $quizId = $_POST['quiz_id'];

        if (!isset($_FILES['docx']) || $_FILES['docx']['error'] !== UPLOAD_ERR_OK) {
            die("فایل ارسال نشد!");
        }

        $filePath = $_FILES['docx']['tmp_name'];

        // خواندن docx
        $phpWord = IOFactory::load($filePath);
        $text = "";

        foreach ($phpWord->getSections() as $section) {
            foreach ($section->getElements() as $element) {
                if (method_exists($element, "getText")) {
                    $text .= $element->getText() . "\n";
                }
                if (method_exists($element, "getElements")) {
                    foreach ($element->getElements() as $child) {
                        if (method_exists($child, "getText")) {
                            $text .= $child->getText() . "\n";
                        }
                    }
                }
            }
        }

        // شکستن کل محتوا به خطوط
        $lines = array_filter(array_map('trim', explode("\n", $text)));

        //------------------------------------------------------------------
        // الگوریتم ایمپورت
        //------------------------------------------------------------------
        $repo = new QuestionRepository();

        $mapping = [
            'الف' => 0,
            'ب'   => 1,
            'ج'   => 2,
            'د'   => 3,
        ];

        $currentQuestionText = null;
        $currentOptions = [];
        $correctLetter = null;

        $createdCount = 0;

        foreach ($lines as $line) {

            // پاسخ: الف
            if (str_starts_with($line, "پاسخ")) {
                $correctLetter = trim(str_replace("پاسخ:", "", $line));
                $correctLetter = preg_replace('/[^آ-ی]/u', '', $correctLetter); // فقط حروف فارسی

                // ذخیره سؤال
                if ($currentQuestionText) {

                    $qid = $repo->create([
                        "quiz_id" => $quizId,
                        "type" => "mcq_single",
                        "body" => $currentQuestionText,
                        "explanation" => "",
                        "difficulty" => 2,
                    ]);

                    // ذخیره گزینه‌ها
                    foreach ($currentOptions as $index => $optText) {
                        $isCorrect = (isset($mapping[$correctLetter]) &&
                            $mapping[$correctLetter] == $index) ? 1 : 0;

                        $repo->addOption($qid, $optText, $isCorrect);
                    }

                    $createdCount++;
                }

                // ریست برای سؤال بعدی
                $currentQuestionText = null;
                $currentOptions = [];
                $correctLetter = null;

                continue;
            }

            // گزینه‌ها
            if (preg_match('/^(الف|ب|ج|د)\)?\s*\)?\s*(.*)$/u', $line, $m)) {
                $letter = $m[1];
                $textOption = trim($m[2]);

                $currentOptions[$mapping[$letter]] = $textOption;
                continue;
            }

            // اگر خط نه گزینه بود و نه پاسخ → پس متن سؤال است
            if ($currentQuestionText === null) {
                $currentQuestionText = $line;
            }
        }

        //------------------------------------------------------------------

        return View::render("admin/questions/import_result.php", [
            "count" => $createdCount,
            "quiz_id" => $quizId,
        ]);
    }
}