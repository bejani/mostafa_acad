<?php

namespace App\Action\Admin\Quiz;

use App\Core\Auth;
use App\Core\View;
use App\Domain\QuizRepository;

class QuizCreateAction
{
    public function __invoke()
    {
        // جلوگیری از دسترسی غیر ادمین
        if (!Auth::isAdmin()) {
            return View::redirect(View::baseUrl('/login'));
        }

        // --- دریافت داده‌های فرم ---
        $title     = trim($_POST['title'] ?? '');
        $module    = $_POST['module'] ?? 'Word';
        $timeLimit = (int)($_POST['time_limit_seconds'] ?? 0);
        $qCount    = (int)($_POST['question_count'] ?? 20);
        $published = isset($_POST['is_published']) ? 1 : 0;

        // --- اعتبارسنجی پایه ---
        if ($title === '') {
            return View::redirect('/admin/quizzes/create');
        }

        // --- ایجاد آزمون ---
        $repo = new QuizRepository();

        $repo->create([
            'title'              => $title,
            'module'             => $module,
            'time_limit_seconds' => $timeLimit,
            'question_count'     => $qCount,
            'is_published'       => $published,
            'created_by'         => Auth::user()['id'] ?? null,
        ]);

        // --- بازگشت به لیست ---
        return View::redirect('/admin/quizzes');
    }
}