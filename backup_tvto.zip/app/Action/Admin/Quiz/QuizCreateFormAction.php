<?php

namespace App\Action\Admin\Quiz;

use App\Core\Auth;
use App\Core\View;

class QuizCreateFormAction
{
    public function __invoke()
    {
        if (!Auth::isAdmin()) {
            return View::redirect('/login');
        }

        $modules = [
            'ICDL_Concepts' => 'مفاهیم پایه ICDL',
            'Windows'       => 'Windows',
            'Word'          => 'Word',
            'Excel'         => 'Excel',
            'PowerPoint'    => 'PowerPoint',
            'Access'        => 'Access',
            'Internet'      => 'Internet',
        ];

        return View::render("admin/quizzes/create.php", [
            'modules' => $modules,
        ]);
    }
}