<?php

namespace App\Action\Auth;

use App\Core\Auth;
use App\Core\View;

class LoginAction
{
    public function __invoke()
    {
        if (Auth::check()) {
            if (Auth::isAdmin()) {
                return View::redirect(View::baseUrl('/admin/dashboard'));
            }
            if (Auth::isStudent()) {
                return View::redirect(View::baseUrl('/student/panel'));
            }
        }

        return View::render('auth/login.php');
    }
}