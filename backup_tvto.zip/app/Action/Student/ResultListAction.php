<?php

namespace App\Action\Student;

use App\Core\Auth;
use App\Core\View;
use App\Domain\AttemptRepository;

class ResultListAction
{
    public function __invoke()
    {
        if (!Auth::isStudent()) {
            return View::redirect('/login');
        }

        $repo = new AttemptRepository();
        $attempts = $repo->getUserAttempts(Auth::id());

        return View::render('student/results/list.php', [
            'attempts' => $attempts
        ], 'student');
    }
}