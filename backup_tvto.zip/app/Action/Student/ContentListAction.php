<?php

namespace App\Action\Student;

use App\Core\Auth;
use App\Core\View;
use App\Domain\ContentRepository;

class ContentListAction
{
    public function __invoke()
    {
        if (!Auth::isStudent()) {
            // return View::redirect('/tvto_portal/public/login');
            return View::redirect('/login');
        }

        $repo = new ContentRepository();
        $contents = $repo->allPublished();

        return View::render("student/contents/list.php", [
            "contents" => $contents
        ], "student");
    }
}