<?php

namespace App\Action\Student;

use App\Core\Auth;
use App\Core\View;
use App\Domain\AttemptRepository;
use App\Domain\QuestionRepository;

class QuizSubmitAction
{
    public function __invoke()
    {
        if (!Auth::isStudent()) return View::redirect('/login');

        $attemptId = $_POST['attempt_id'] ?? null;
        if (!$attemptId) return "Attempt not found.";

        $attemptRepo  = new AttemptRepository();
        $questionRepo = new QuestionRepository();

        // Get questions for this attempt
        $questions = $questionRepo->byAttempt($attemptId);

        $correct = 0;
        $total   = count($questions);

        foreach ($questions as $q) {
            $key = "q" . $q['id'];
            $selectedOption = $_POST[$key] ?? null;

            // Save answer
            $attemptRepo->saveAnswer($attemptId, $q['id'], $selectedOption);

            // Check correctness
            if ($selectedOption && $questionRepo->isCorrectOption($selectedOption)) {
                $correct++;
            }
        }

        $score = round(($correct / $total) * 100, 2);

        // Get attempt start
        $attempt = $attemptRepo->find($attemptId);

        $start = strtotime($attempt['started_at']);
        $end   = time();
        $duration = $end - $start;

        // Finish attempt
        $attemptRepo->finish($attemptId, $score, $duration);

        return View::redirect(
            '/student/results?attempt=' . $attemptId
        );
    }
}