<?php

namespace App\Action\Student;

use App\Core\Auth;
use App\Core\View;
use App\Domain\QuizRepository;
use App\Domain\AttemptRepository;
use App\Domain\QuestionRepository;

class QuizTakeAction
{
    public function __invoke()
    {
        if (!Auth::isStudent()) {
            return View::redirect('/login');
        }

        $quizId = $_GET['quiz_id'] ?? null;

        if (!$quizId) {
            die("Invalid quiz.");
        }

        // دریافت آزمون
        $quizRepo = new QuizRepository();
        $quiz = $quizRepo->find($quizId);

        if (!$quiz) {
            die("Quiz not found");
        }

        // دریافت سؤالات + گزینه‌ها
        $questionRepo = new QuestionRepository();
        $questions = $questionRepo->byQuiz($quizId);

        // ایجاد تلاش جدید
        $attemptRepo = new AttemptRepository();
        $attemptId = $attemptRepo->create([
            'quiz_id' => $quizId,
            'user_id' => Auth::id(),
            'score' => 0,
            'duration_seconds' => 0
        ]);

        // نمایش صفحه آزمون
        return View::render('student/quizzes/take.php', [
            'quiz' => $quiz,
            'questions' => $questions,
            'attempt_id' => $attemptId
        ], 'student');
    }
}