<?php

declare(strict_types=1);

session_start();

// Autoload
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $baseDir = __DIR__ . '/../app/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Load app config
require __DIR__ . '/../app/app.php';

use App\Core\Router;

// 1) این Router اصلی پروژه است
$router = new Router();

// 2) مسیرها باید روی همین Router ثبت شوند
require __DIR__ . '/../app/routes.php';

// 3) Dispatch
$response = $router->dispatch();

if (is_string($response)) {
    echo $response;
}